# STW302CEM Agile Group Project

Group name
> Phoenix

Section: 19A
Group members: Netra, Sushan, Romisha, Biju 

1. Introduction
A cake ordering web application for prospective bakery, written in Python using the Django framework.

2. Features
..1. Customers can create an account.
--2. Admin account.
--3. Customers can view and order cakes online.
--4. Admin can manage users.
--5. Admin can perform CRUD operations on cake details.
--6. Admin can view order details.

3. Demo
'<youtube link here>'

